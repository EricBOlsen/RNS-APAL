/* Dummy-Assertions */

#define Assert(a)                 (void)0
#define AssertMsg(a, b)           (void)0
#define AssertAction(a, b)        (void)0
#define AssertMsgAction(a, b, c)  (void)0

